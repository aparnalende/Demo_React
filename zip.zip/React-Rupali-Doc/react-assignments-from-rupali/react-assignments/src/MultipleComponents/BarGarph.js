import React from 'react';
import {Bar} from 'react-chartjs-2';
import DatePicker from "react-date-picker";


const state = {
  labels: ['21/12/2020', '11/01/2021', '02/08/2021','22/07/2021', '20/12/2029','11/11/2020', '10/04/2021', '23/12/2019', '06/12/2020' ,'18/11/2019',
           '12/12/2020', '30/02/2021'],
  datasets: [
    {
      label: 'Total Active Users',
      backgroundColor: 'blue',
      data: [ 80000, 110000, 80000, 100000, 125000, 112000, 160000, 120000, 90000, 60000, 115000, 200000]
    }
  ]
}

export default class App extends React.Component {
    state = {
        date: new Date()
      };
    
      onChange = (date) => {
        let formattedDate = `${
          date.getMonth() + 1
        }/${date.getDate()}/${date.getFullYear()}`;
        this.setState({ date: formattedDate });
      };
    
  render() 
  {   let f = new Date(this.state.date);
    return (
    <div className="container">
      <div className="Usergraph" style={{width: "45vw", borderRadius: '10px', backgroundColor: 'white', padding: "20px",marginTop: "2vw"}}>  
         <div style={{float:'right'}} >
             <label>  Select Date : &nbsp; </label>
                <DatePicker onChange={this.onChange} value={f} />
        </div> 
        <Bar
          data={state}
          options={{
            title:{
              display:true,
              text:'Average Rainfall per month',
              fontSize:20
            },
            legend:{
              display:true,
              position:'right'
            }
          }}
        />
      </div>
      </div>
    );
  }
}