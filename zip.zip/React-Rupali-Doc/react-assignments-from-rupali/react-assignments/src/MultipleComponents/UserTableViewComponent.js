import React, { useState, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import Avatar from "react-avatar";
import { FaFilter } from "react-icons/fa";
import { BsArrowBarUp } from "react-icons/bs";
import { AiOutlineDelete } from "react-icons/ai";
import { MdModeEdit } from "react-icons/md";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import EditUserComponent from "./EditUserComponent";
import { ThreeSixtyOutlined } from "@material-ui/icons";
import ReactPaginate from "react-paginate";
import "./paginationStyles.css";
import { Dropdown } from "react-bootstrap";

function UserTableViewComponent(props) {
  const [user, setUser] = useState([]);
  const [tempList, setTempList] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [pageNumber, setPageNumber] = useState(0);
  const [finduser, setfinduser] = useState("");

  const usersPerPage = 10;
  const pagesVisited = pageNumber * usersPerPage;

  const pageCount = Math.ceil(user.length / usersPerPage);

  const changePage = ({ selected }) => {
    setPageNumber(selected);
  };

  useEffect(() => {
    let userList = JSON.parse(localStorage.getItem("UserList")) || [];
    setUser(userList);
  }, []);

  const removeData = (id) => {
    console.log("Id to delete-------", id);
    let tempList = JSON.parse(localStorage.getItem("UserList"));
    tempList.splice(id, 1);
    localStorage.setItem("UserList", JSON.stringify(tempList));
    setTempList(tempList);
    toast.error("User has been deleted successfully......");
    window.location.reload();
  };

  const editUser = (id) => {
    alert("editUser function is called..");
    console.log("Id to be edited", id);
    let tempList = JSON.parse(localStorage.getItem("UserList"));

    var obj = tempList[id];
    console.log("Obj----", obj);
  };

  const sortRecordByAZ = () => {
    user.sort((a, b) => {
      return a.Name.localeCompare(b.Name);
    });
  };

  const sortRecordByDesc = () => {
    user.sort((a, b) => {
      return b.Name.localeCompare(a.Name);
    });
  };

  const sortRecordByDate = () => {
    user.sort((a, b) => {
      return a.date > b.date ? 1 : -1;
    });
  };

  const filterByUser = () => {
    setUser(
      user.filter((res) => {
        return res.Role == "user";
      })
    );
  };

  const filterByAdmin = () => {
    setUser(
      user.filter((res) => {
        return res.Role == "admin";
      })
    );
  };

  return (
    <>
      <div className="container" style={{ width: "80%", marginTop: "80px" }}>
        ``
        <div></div>
        <div style={{ paddingTop: "10px" }}>
          <form class="form-inline my-2 my-lg-0">
            <Dropdown>
              <Dropdown.Toggle
                variant="success"
                className="btn btn-light dropdown-toggle "
                style={{
                  backgroundColor: "purple",
                  color: "white",
                  float: "left",
                }}
                id="dropdown-basic"
              >
                <FaFilter />
                Filter By
              </Dropdown.Toggle>

              <Dropdown.Menu>
                <Dropdown.Item onClick={() => filterByUser()}>
                  User
                </Dropdown.Item>
                <Dropdown.Item onClick={() => filterByAdmin()}>
                  Admin
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>

            <Dropdown>
              <Dropdown.Toggle
                variant="success"
                className="btn btn-light dropdown-toggle "
                style={{
                  backgroundColor: "purple",
                  color: "white",
                  float: "left",
                }}
                id="dropdown-basic"
              >
                <BsArrowBarUp />
                Sort By
              </Dropdown.Toggle>

              <Dropdown.Menu>
                <Dropdown.Item onClick={() => sortRecordByAZ()}>
                  A-Z
                </Dropdown.Item>
                <Dropdown.Item onClick={() => sortRecordByDesc()}>
                  Z-A
                </Dropdown.Item>
                <Dropdown.Item onClick={() => sortRecordByDate()}>
                  Created Date
                </Dropdown.Item>
                <Dropdown.Item href="#/action-3">Last Updated</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>

            <div style={{ float: "right" }}>
              <input
                class="form-control mr-sm-2 ml-5"
                type="text"
                placeholder="Search.."
                aria-label="Search"
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                }}
              />
            </div>
          </form>
        </div>
        <hr></hr>
        <br></br>
        <br></br>
        <div>
          {user.length ? (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th scope="col">
                    <div className="custom-control custom-checkbox">
                      <input type="checkbox" className="custom-control-input" />
                      <label className="custom-control-label"></label>
                    </div>
                  </th>
                  <th scope="row">Id</th>
                  <th>Name </th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Action</th>

                  <th></th>
                </tr>
              </thead>
              <tbody>
                {user
                  .filter((val) => {
                    if (searchTerm == "") {
                      return val;
                    } else if (
                      val.Name.toLowerCase().includes(
                        searchTerm.toLocaleLowerCase()
                      )
                    ) {
                      return val;
                    }else if (
                      val.Email.toLowerCase().includes(
                        searchTerm.toLocaleLowerCase()
                      )
                    ) {
                      return val;
                    }
                  })
                  .slice(pagesVisited, pagesVisited + usersPerPage)
                  .map((u, i) => {
                    return (
                      <tr>
                        <td>
                          <div className="custom-control custom-checkbox">
                            <input
                              type="checkbox"
                              className="custom-control-input"
                            />
                            <label className="custom-control-label"></label>
                          </div>
                        </td>
                        <td>{i + 1}</td>
                        <td>
                          <Avatar
                            className="mr-2 rounded"
                            name={u.Name}
                            size="30"
                          />
                          {u.Name}
                        </td>
                        <td>{u.Email}</td>
                        <td>{u.Phone}</td>
                        <td>{u.Role}</td>
                        <td>{u.Status}</td>
                        <td>{u.date}</td>

                        <td>
                          <button
                            type="button"
                            onClick={() => removeData(i)}
                            className="btn btn-light "
                          >
                            <AiOutlineDelete />
                          </button>

                          <Link to={`/edit/${u.Id}`}>
                            <MdModeEdit />
                          </Link>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          ) : (
            <div>
              <br></br>
              <h3>No User to display.....</h3>
            </div>
          )}

          <ReactPaginate
            previousLabel={"Previous"}
            nextLabel={"Next"}
            pageCount={pageCount}
            onPageChange={changePage}
            containerClassName={"paginationBttns"}
            previousLinkClassName={"previousBttn"}
            nextLinkClassName={"nextBttn"}
            activeClassName={"paginationActive"}
          />
        </div>
      </div>

      <ToastContainer />
    </>
  );
}

export default UserTableViewComponent;
