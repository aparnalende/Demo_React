# EmployeeDatabaseManagement-Based-On-RolesAndOrganizationalUnit

Note.: Except App.js other file recommended to keep in Project folder.

1. Application Start with App.js

2. Login Page: Default Username and Password is provided for admin login
    Username: Admin 
    Password: 123

3. After login it redirect to main page 'WebPageMain.js'
    where Employee ,Roles and Organization is displayed

4. If you click on Organization you have to add oraganization respective your company
    After adding organization data will be stored at localStorage, where you can delete ,add new data.

5. If you click on Roles , same as organization after adding data at roles it will be stored at localStorage, everytime data will be update at localstorage as per changes.

6. After clicking employee, you'll be able to access employee and add new employee. As per oraganization and roles if you add employee in perticular organization size of organizational unit will increase that changes you can see in organization data list in size column.

7. You are also able delete data at employee , organization and roles.
