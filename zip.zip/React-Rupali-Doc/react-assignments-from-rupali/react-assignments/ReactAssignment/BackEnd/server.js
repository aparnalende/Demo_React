const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const nodemailer = require('nodemailer');
const xoauth2 = require("xoauth2");

// routers
const routerUser = require('./routes/user')

const app = express()

// add json parser
app.use(bodyParser.json())
app.use(cors('*'))

// app.get('/', (request, response) => {

//   const { email } = request.body
//   const statement = `select id from user where email = '${email}'`
  
//   response.send('<h1>Welcome to my backend</h1>')

//   let transporter = nodemailer.createTransport({
//     host: "smtp.gmail.com",
//     auth: {
//       type: "login", // default
//       user: "varshaghate9421@gmail.com",
//       pass: "8888763161"
//     }
// });
  
//   var mailOptions = {
//     from: 'Dave <varshaghate9421@gmail.com>',
//     to: '  ',
//     subject: 'Nodemailer test',
//     text: 'Hello world'
//   }
  
//   transporter.sendMail(mailOptions, function(err, res) {
//     if (err) {
//       console.log(err);
//     } else {
//       console.log('Email sent');
//     }
//   })

// })


app.use('/user', routerUser)


app.listen(4000, '0.0.0.0', () => {
  console.log('server started on port 4000')
})