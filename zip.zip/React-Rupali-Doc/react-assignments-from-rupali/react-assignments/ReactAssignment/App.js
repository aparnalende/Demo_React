import "./App.css";
import Sidebar from "../src/MultipleComponents/Sidebar";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  BrowserRouter,
} from "react-router-dom";
import AddUserComponent from "../src/MultipleComponents/AddUserComponent";
import Routers from "../src/MultipleComponents/Routers";
import Header from "../src/MultipleComponents/Header";

function App() {
  return (
    <Router>
      <Header />

      <Switch>
        <Routers />
      </Switch>
    </Router>
  );
}

export default App;


